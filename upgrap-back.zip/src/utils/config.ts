export default {
    SECRET: 'customer-api'
}