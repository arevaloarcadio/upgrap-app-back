import { verifyToken } from "./auth.jwt";

export {
    verifyToken
}