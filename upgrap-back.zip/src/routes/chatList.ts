import {Router} from 'express';
const router = Router();

// router.get('/chatlist/:id')

export default router;